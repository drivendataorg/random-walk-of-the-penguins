# Thomas Bolton
# thomasmichaelbolton@gmail.com
# 27/06/2017
#
# This script makes predictions for the DrivenData challenge
# titled "Random Walk of the Penguins". This particular submission
# placed 2nd on the private leaderboard.
#
# The only data file this script depends on is the .csv file titled
# 'training_set_nest_counts.csv', which should be in the same
# directory as this particular script.
#
# The output is a file titled 'predictions.csv', which contains the
# population nest count predictions for each site, for 2014-2017.
#
# The method involves a mix of the following techniques:
#
# - Using the most recent nest count as the prediction for 2014, 2015, 2016 and 2017.
# - Using data on chicks+adults to estimate recent nest counts.
# - Linear and exponential models in time.
# - Using in-sample prediction of the most recent value using an AR(1) model.
#
# Other techniques used which were not as successful are discussed in my report.

import csv
import numpy as np
import pandas as pd

from statsmodels.tsa.ar_model import AR
from sklearn.linear_model import LinearRegression


##### Load data #####

# extract the nest counts, the name of the species, and the years at which observations were made
obsCounts = pd.read_csv('data/training_set_nest_counts.csv', index_col=[0, 1]).as_matrix()
obsSpecies = pd.read_csv('data/training_set_nest_counts.csv').as_matrix()[:, 1]
obsYears = pd.read_csv('data/training_set_nest_counts.csv', index_col=[0, 1]).columns.values.astype(np.float)

##### Non-nest count predictions #####
#
# All the data points in 'training_set_nest_counts.csv' are of nest counts only; this file does not contain any
# data on counts of adults or chicks. For certain sites, there's data on adults/chick estimates in the file called
# 'training_set_observations.csv'. Some of this adult/chick data is more recent than the most recent nest count for
# that site, which can be used to improve predictions. Rough estimates of the nest counts can then be made using the 
# adult/chick data which is hopefully more accurate than using the older nest counts.
# 
# By manually looking at each site at where adult/chick data is more recent, rough estimates of the latest
# nest count can be made by seeing how previously adult/chick data corresponds to nest counts. Those sites,
# as well as the manual 'by-eye' predictions are given below (the integer corresponds to the position in
# the submission table).

# the sites with recent data on chicks or adults
adultChickSites = [ 2, 6, 18, 22, 68, 72, 74, 92, 105, 117, 131, 154, 163, 164, 172, 197, 239, 264, 274, 305, 309,
                    316, 362, 375, 405, 424, 440, 459, 497, 502, 557, 561, 566, 577, 581, 587, 590, 605 ]

# the corresponding estimate made manually for each of the above sites
adultChickPred = [ 150, 2000, 1000, 250, 8000, 18000, 3000, 1000, 700, 4000, 200, 10000, 450, 7000, 47, 1400, 3000,
                   3000, 150, 50, 18, 20000, 1000, 200, 24000, 15000, 50, 75000, 3200, 16, 5000, 2600, 15000, 400,
                   1000, 10000, 100, 2500 ]

##### Make predictions #####

# pre-allocate an array to store the predicted nest counts for 2014, 2015, 2016 and 2017
# for each row in the submission file
predictions = np.zeros( (648,4) )

# loop through time series in the training data
for n, counts in enumerate(obsCounts):

    # the integer 'n' is the index for the row in 'training_set_nest_counts.csv'. Get the time series
    # data for this particular row
    countTemp = counts[~np.isnan(counts)]   	# get the non-nan nest counts for this row 
    yearsTemp = obsYears[~np.isnan(counts)]	    # get the years at which the observations were made
    speciesTemp = obsSpecies[n]			        # get the name of the species of this row

    ##### Predictions for time series with recent adult/chick data #####

    if n in adultChickSites :

        pred = adultChickPred[ adultChickSites.index(n) ]
        predictions[n,:] = [ pred, pred, pred, pred ]
        continue

    ##### Prediction for all other time series #####

    # sample size i.e. number of data points in this particular time series
    N = len(countTemp)

    if N == 0 :
        predictions[n,:] = [ 0.0, 0.0, 0.0, 0.0 ]

    elif N == 1 :
        # the majority of gentoo penguin populations are increasing in time. Therefore assume
        # that gentoo sites with only one data point will increase by 1% per year. Otherwise
        # simply use the single value as the prediction.

        if speciesTemp == 'gentoo penguin' :

            deltaYears = 2014 - yearsTemp
            newPred = countTemp * ( 1 + 0.01 * deltaYears )
            predictions[n,:] = [ newPred, newPred, newPred, newPred ]

        else :
            predictions[n,:] = [ countTemp, countTemp, countTemp, countTemp ]

    elif N > 1 :

        # The majority of time series behaviour like a random walk, where the most accurate
        # prediction is simply the most recent value i.e. persistance. Use the most recent
        # value for predictions. Some special cases below are treated differently.
        newPred = countTemp[-1]
        predictions[n,:] = [ newPred, newPred, newPred, newPred ]

    ##### AR(1) #####
    #
    # For time series with 10, 11 or 12 data points, using in-sample prediction of the most
    # recent value using an AR(1) model produced an improvement over simply the most recent value.
    # You generally need at least 10 data points to get a statistically significant AR(1) coefficient.
    # I tried this method for N>=13 but the method resulted in a large AMAPE for some reason.
    #
    if N >= 10 and N < 13:

        ##### Fit AR(1) model #####
        model = AR(endog=countTemp).fit(maxlag=1, trend='nc')

        yPred = model.predict()[-1]  # use the models estimate of the most recent value as the prediction

        # p-value check
        if model.pvalues[0] > 0.1: continue   # check the statistical power of the AR coefficent (i.e. how good the model is)

        predictions[n, :] = [yPred, yPred, yPred, yPred]


    ##### Fit linear model for special cases #####
    #
    # These particular sites were judged by eye to be particularly good for a linear regression in time
    #
    if n in [ 39, 56, 445, 339, 451 ] :

        model = LinearRegression()
        model.fit( yearsTemp.reshape( (N,1) ), countTemp.reshape( (N,1) ) )

        predictions[n,:] = model.predict( np.array( [2014, 2015, 2016, 2017 ] ).reshape( (4,1) ) ).reshape( (4,) )

        # 56 and 495 look slightly off
        if n == 56 : predictions[n,:] = [3500,3650,3800,3950]
        if n == 445 : predictions[n,:] = [3550,3650,3750,3850]

    ##### Fit exponential for special cases #####
    #
    # These particular sites displayed exponential behaviour, so a linear regression in time was performed
    # on log-transformed nest counts
    #
    if n in [ 23, 231, 443, 160, 595, 337 ] :

        model = LinearRegression()
        model.fit( yearsTemp.reshape( (N,1) ), np.log( countTemp + 1).reshape( (N,1) ) )

        predictions[n,:] = np.exp( model.predict( np.array( [2014,2015,2016,2017] ).reshape( (4,1) ) ) ).reshape((4,)) - 1

        # 231 looks slightly off
        if n == 231 : predictions[n,:] += 40

##### make predictions.csv sumbission file #####

# Linear regressions can produce negative predictions; replace
# these with zero (you can't have negative penguin population counts)
predictions[ predictions<0 ] = 0.0
predictions = np.round( predictions )

# first make into list
predictions = predictions.tolist()

# get site_id and species for each count
dataFrame = pd.read_csv('training_set_nest_counts.csv', index_col=[0,1] )

for n, row in enumerate( dataFrame.iterrows() ) :

    # add the site_id and species name to the start of each prediction
    pred = predictions[n]
    pred.insert( 0, row[0][1] )   # species name
    pred.insert( 0, row[0][0] )   # site_id
    predictions[n] = pred

# add header
predictions.insert( 0, ['site_id','common_name','2014','2015','2016','2017'] )

# write to .csv
with open("predictions.csv", "wb") as f:
    writer = csv.writer( f )
    writer.writerows( predictions )
































