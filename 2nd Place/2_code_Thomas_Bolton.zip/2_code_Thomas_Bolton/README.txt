This file provides a description of the code which placed 2nd in the DrivenData
challenge titled "Random Walk of the Penguins".

Thomas Bolton
thomasmichaelbolton@gmail.com
27/06/2017

##### The Files #####

'makePredictions.py' :

This is a python script which loads in the training data, makes predictions using various models, and then
writes the final predictions to a .csv file which it saves. In order to run, the python script depends on
the following packages:

- csv
- numpy
- pandas
- statsmodels
- sklearn

The script was run with python 2.7.13. The script 'madePredictions.py' depends on while file only and that
is to load in the training data. This file is called 'training_set_nest_counts.csv' and should be in the same
directory as 'makePredictions.py'. The only step that needs completing is to execute the script 'makePredictions.py'.
