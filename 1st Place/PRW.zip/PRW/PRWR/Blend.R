library(forecast)
library(imputeTS)
library(dplyr)

rm(list = ls())

# source("config.R")
# setwd(DATA_DIR)


ArimaDF = read.csv("ROutput/PredictionsAutoArimaStineApprox.csv")

ETSDF = read.csv("ROutput/PredictionsETSStine.csv")

XGBDF = read.csv("predictionsXGBInterpolationSeed.csv")

RFDF = read.csv("predictionsRFInterpolationWithSeed.csv")

ProphetDF = read.csv("ROutput/ProphetScaled.csv")

TestCols = subset(ArimaDF,select = c(1,2))

ArimaDF = ArimaDF %>% select(-site_id,-common_name)

ETSDF = ETSDF %>% select(-site_id,-common_name)

XGBDF = XGBDF %>% select(-site_id,-common_name)

RFDF = RFDF %>% select(-site_id,-common_name)

ProphetDF = ProphetDF  %>% select(-site_id,-common_name)

colnames(ArimaDF) = c("2014","2015","2016","2017")

colnames(ETSDF) = c("2014","2015","2016","2017")

colnames(XGBDF) = c("2014","2015","2016","2017")

colnames(RFDF) = c("2014","2015","2016","2017")

colnames(ProphetDF) = c("2014","2015","2016","2017")


CombinedDF2014 = data.frame("Arima" = numeric(),"ETS" =numeric(),"XGB"= numeric(),"RF"=numeric(),"Prophet"=numeric())

ArimaDF$`2014` = as.numeric(ArimaDF$`2014`)
ArimaDF$`2015` = as.numeric(ArimaDF$`2015`)
ArimaDF$`2016` = as.numeric(ArimaDF$`2016`)
ArimaDF$`2017` = as.numeric(ArimaDF$`2017`)

ETSDF$`2014` = as.numeric(ETSDF$`2014`)
ETSDF$`2015` = as.numeric(ETSDF$`2015`)
ETSDF$`2016` = as.numeric(ETSDF$`2016`)
ETSDF$`2017` = as.numeric(ETSDF$`2017`)

XGBDF$`2014` = as.numeric(XGBDF$`2014`)
XGBDF$`2015` = as.numeric(XGBDF$`2015`)
XGBDF$`2016` = as.numeric(XGBDF$`2016`)
XGBDF$`2017` = as.numeric(XGBDF$`2017`)

RFDF$`2014` = as.numeric(RFDF$`2014`)
RFDF$`2015` = as.numeric(RFDF$`2015`)
RFDF$`2016` = as.numeric(RFDF$`2016`)
RFDF$`2017` = as.numeric(RFDF$`2017`)

ProphetDF$`2014` = as.numeric(ProphetDF$`2014`)
ProphetDF$`2015` = as.numeric(ProphetDF$`2015`)
ProphetDF$`2016` = as.numeric(ProphetDF$`2016`)
ProphetDF$`2017` = as.numeric(ProphetDF$`2017`)

CombinedDF2014 = as.data.frame(cbind(ArimaDF$`2014`,ETSDF$`2014`,XGBDF$`2014`,RFDF$`2014`,ProphetDF$`2014`))
CombinedDF2015 = as.data.frame(cbind(ArimaDF$`2015`,ETSDF$`2015`,XGBDF$`2015`,RFDF$`2015`,ProphetDF$`2015`))
CombinedDF2016 = as.data.frame(cbind(ArimaDF$`2016`,ETSDF$`2016`,XGBDF$`2016`,RFDF$`2016`,ProphetDF$`2016`))
CombinedDF2017 = as.data.frame(cbind(ArimaDF$`2017`,ETSDF$`2017`,XGBDF$`2017`,RFDF$`2017`,ProphetDF$`2017`))

CDF2014 = rowMeans(CombinedDF2014)
CDF2015 = rowMeans(CombinedDF2015)
CDF2016 = rowMeans(CombinedDF2016)
CDF2017 = rowMeans(CombinedDF2017)

#Prepare the dataframe for the Predictions
predictionsDF = data.frame("2014" = numeric(), "2015" = numeric(), "2016" = numeric(), "2017" = numeric(),stringsAsFactors=FALSE)

predictionsDF = cbind(CDF2014,CDF2015,CDF2016,CDF2017)

predictionsDF2 = cbind(TestCols,predictionsDF)

colnames(predictionsDF2)= c("site_id","common_name","2014","2015","2016","2017")

write.csv(predictionsDF2, file = "ROutput/ArimaApproxETSXGBRFProphetScaled.csv",row.names=FALSE)

