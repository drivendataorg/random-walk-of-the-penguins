library(prophet)
library(imputeTS)
library(dplyr)

rm(list = ls())

# source("config.R")

# Interpolate using the following methods in the order mentioned below:
# Stine
# Last Observation Carried Forward
# Next Observation Carried Backward 
# Replace by Zero
transformTimeSeries = function(tsTrain,i) 
{
  tsTrain[i,] = tryCatch({
    na.interpolation(tsTrain[i,], option = "stine")
  },
  error = function(e) {
    tsTrain[i,]
  })
  
  tsTrain[i,] = tryCatch({
    na.locf(tsTrain[i,])
  },
  error = function(e) {
    tsTrain[i,]
  })
  
  tsTrain[i,] = tryCatch({
    na.locf(tsTrain[i,],option="nocb")
  },
  error = function(e) {
    tsTrain[i,]
  })
  
  tsTrain[i,] = na.replace(tsTrain[i,], fill = 0.0)
  
  return(tsTrain[i,] )
  
}


makeToZero = function(preds)
{
  if(preds < 0)
  {
    return(0.0)
  }
  else
  {
    return(preds)
  }
}

# setwd(DATA_DIR)

Train = read.csv("data/training_set_nest_counts.csv")

Test = read.csv("data/submission_format.csv")

TestCols = subset(Train,select = c(1,2))

# Remove all columns before 1980
dfTrain = subset(Train, select = -c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23) )

tsTrain = ts(dfTrain)

length = nrow(Train)

customlength = length

#Prepare the dataframe for the Predictions
predictionsDF = data.frame("2014" = numeric(), "2015" = numeric(), "2016" = numeric(), "2017" = numeric(),stringsAsFactors=FALSE)

#########################################################

startYear = 1980

len = 34

as.Date(paste0(startYear,"-","01","-","01"))

YearMatrix <- as.Date(matrix(ncol=1, nrow=len))

for( i in 1: len)
{
  YearMatrix[i] = as.Date(paste0(startYear,"-","01","-","01"))
  
  startYear = startYear +1
  
}

Year = data.frame(YearMatrix)

colnames(Year) = c("ds")

########################################################
for( counter in 1:customlength)
{
  df = transformTimeSeries(tsTrain,counter)
  
  df = as.data.frame(df)
  
  df = df %>% mutate ( ds = Year$ds)
  
  colnames(df) = c("y","ds")
  
  if(sum(df$y) == 0)
  {
    predictions[1:4] = 0
  }
  else
  {
    # Changing the default of changepoint.prior.scale
    m <- prophet(df,changepoint.prior.scale = 0.1)
    
    future <- make_future_dataframe(m, periods = 4,freq = "year")
    
    forecast <- predict(m, future)
    
    predictions = as.numeric(forecast$yhat[35:38])
    
    predictions = sapply(predictions,makeToZero)
  }
  
  cat( " Completed " , counter ,"Rows ",  " \n ")
  
  predictionsDF = rbind(predictionsDF,predictions)
  
}

predictionsDF2 = cbind(TestCols,predictionsDF)

colnames(predictionsDF2)= c("site_id","common_name","2014","2015","2016","2017")

write.csv(predictionsDF2, file = "ROutput/ProphetScaled.csv",row.names=FALSE)




