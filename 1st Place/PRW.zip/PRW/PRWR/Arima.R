library(forecast)
library(imputeTS)

rm(list = ls())

source("config.R")

# Interpolate using the following methods in the order mentioned below:
# Stine
# Last Observation Carried Forward
# Next Observation Carried Backward 
# Replace by Zero
# Perform auto.arima using the forecast package
predictTimeSeries = function(tsTrain,i) 
{
  tsTrain[i,] = tryCatch({
    na.interpolation(tsTrain[i,], option = "stine")
  },
  error = function(e) {
    tsTrain[i,]
  })
  
  tsTrain[i,] = tryCatch({
    na.locf(tsTrain[i,])
  },
  error = function(e) {
    tsTrain[i,]
  })
  
  tsTrain[i,] = tryCatch({
    na.locf(tsTrain[i,],option="nocb")
  },
  error = function(e) {
    tsTrain[i,]
  })
  
  tsTrain[i,] = na.replace(tsTrain[i,], fill = 0.0)
  
  fit = auto.arima(tsTrain[i,],stepwise=FALSE, approximation=FALSE)
  
  return(fit)
  
}

makeToZero = function(preds)
{
  if(preds < 0)
  {
    return(0.0)
  }
  else
  {
    return(preds)
  }
}

setwd(DATA_DIR)

Train = read.csv("data/training_set_nest_counts.csv")

Test = read.csv("data/submission_format.csv")

TestCols = subset(Train,select = c(1,2))

# Remove all columns before 1980
dfTrain = subset(Train, select = -c(0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23) )

tsTrain = ts(dfTrain)

length = nrow(Train)

customlength = length

#Prepare the dataframe for the Predictions
predictionsDF = data.frame("2014" = numeric(), "2015" = numeric(), "2016" = numeric(), "2017" = numeric(),stringsAsFactors=FALSE)

#Prepare the dataframe for the Order of the Arima ( p, d,q)
orderDF = data.frame(p = integer(), q = integer(), d = integer(),stringsAsFactors=FALSE)

OrderDFAndPvalues = data.frame(p = integer(), q = integer(), d = integer(),pvalues = numeric(),stringsAsFactors=FALSE)

pValuesDF = data.frame(pValues = numeric(),stringsAsFactors=FALSE)

for( counter in 1:customlength)
{
  fit = predictTimeSeries(tsTrain,counter)
  
  #Calculate the residuals from the arima fit
  residualsPValue = Box.test(fit$residuals,lag = 10)
  
  preds = forecast(fit, h = 4)
  
  predictions = as.numeric(preds$mean)
  
  predictions = sapply(predictions,makeToZero)
  
  cat( " Completed " , counter ,"Rows ",  " \n ")
  
  predictionsDF = rbind(predictionsDF,predictions)
  
  Pvalues = residualsPValue$p.value
  
  pValuesDF= rbind(pValuesDF,Pvalues)
  
  orderDF =rbind(orderDF,arimaorder(fit))
}

predictionsDF2 = cbind(TestCols,predictionsDF)

orderDFDF2 = cbind(TestCols,orderDF)

OrderDFAndPvalues= cbind(orderDFDF2,pValuesDF)

colnames(predictionsDF2)= c("site_id","common_name","2014","2015","2016","2017")

colnames(OrderDFAndPvalues)= c("site_id","common_name","p","d","q","pValues")

write.csv(predictionsDF2, file = "ROutput/PredictionsAutoArimaStineApprox.csv",row.names=FALSE)

write.csv(OrderDFAndPvalues, file = "ROutput/PDQAutoArimaStine.csv",row.names=FALSE)



