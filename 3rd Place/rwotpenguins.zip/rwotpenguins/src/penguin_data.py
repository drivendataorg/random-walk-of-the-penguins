import os, time
import pandas as pd
import numpy as np
from tqdm import tqdm_notebook
from sklearn.linear_model import LinearRegression


MAX_YEARS = 55

# Magic numbers
MIN_YEARS_FOR_LINEAR_PREDICTION = 3 # If there are two readings trend might be risky

CONSTANT_TREND_FOR_NO_DATA = 39. / 36. # This the hypothesised increase in population for the years 2014 - 2017 when no model available
CONSTANT_TREND_FOR_MODELS = 19. /18. # Trend for years 2014 - 2015 when model is available (hypothesised)

GENERAL_TREND_WEIGHT = 0.1
LAST_TREND_WEIGHT_YEARS_1_2 = 0.7
LAST_TREND_WEIGHT_YEARS_3_4 = 0.6 #Might have been better to use one value, but in my submission file in accidently used to values
LINEAR_MODEL_FACTOR = 0.5 # How much to weigh the linear model

TIME_FOR_INCREASE_FACTOR = 2 # A factor constant trend in the first two years


# This is the function for prediciton, simple linear model
def train_model_per_row(ts, max_years = MAX_YEARS): 
    # return model re-trained on entire dataset
    ts_valid_years = ts.valid()
    if len(ts_valid_years) < MIN_YEARS_FOR_LINEAR_PREDICTION:
        return None
    final_model = LinearRegression()
    final_model.fit(
        ts_valid_years.index[-max_years:].values.reshape(-1, 1),
        ts_valid_years[-max_years:]
    )

    return final_model



class PenguinData(object):
    def __init__(self):
        self.path_to_data = '../data/'
        self.path_to_predictions = '../predictions/'
        self.count_data_file = 'Random_Walk_of_the_Penguins_-_Nest_count_timeseries.csv'
        self.error_data_file = 'Random_Walk_of_the_Penguins_-_Nest_error_timeseries.csv'
        self.submission_format_file = 'Random_Walk_of_the_Penguins_-_Submission_Format.csv'
        self.prediction_file = 'prediction_aaronr.csv'
        self.load_data()
        self.process_data()

    def load_data(self):
        self.observations = pd.read_csv(os.path.join(self.path_to_data, self.count_data_file), \
                           index_col=[0,1])
        self.errors = pd.read_csv(os.path.join(self.path_to_data, self.error_data_file), \
                 index_col=[0,1])
        
        self.submission_format = pd.read_csv(os.path.join(self.path_to_data, self.submission_format_file), \
                 index_col=[0,1])
    
    def process_data(self):
        self.observations.columns = self.observations.columns.astype(int)
        self.errors.columns = self.errors.columns.astype(int)
        self.submission_format.columns = self.submission_format.columns.astype(int)
        
        self.linear_models_lastreadings = {}
        self.linear_models_allreadings = {}

        for i, row in tqdm_notebook(self.observations.iterrows()):
            self.linear_models_allreadings[i] = train_model_per_row(row)
            self.linear_models_lastreadings[i] = train_model_per_row(row, max_years = 6)
    
    def predict(self):
    # Predictions here have two main models, one for data of 2 or less point and the other for when more than 2 are available.
    # When less than 2 are available than last known count is taked and multiplied by an increase factor (hypothesised)
    # When more than 2 are available than the model takes into account last prediction, trend of last 6 observation and trend of all available data (these can overlap if there are less than 6 observation). These are all factored together
    # The factors for each part of the model were chosen to keep the prediction not too far away from last know observation (within 20% more or less)
    # Note that the linear slope is used and the baseline is replaced
    # In the winning submission nothing there were some negative values that were fixed
        preds = []
        minimal_pred = np.array([1, 1, 1, 1]) #for clarity, minimal values for prediction are 1
        for i, row in tqdm_notebook(self.submission_format.iterrows(),
                                    total=self.submission_format.shape[0]):
            observation = self.observations.loc[i, :] #get current observation
            last_valid_idx = observation.last_valid_index() #get last valid observation year
            last_valid_count = minimal_pred #when no data is available use minimal prediction
            if last_valid_idx:
                last_valid_count = np.repeat(observation[last_valid_idx], 4) #This is the basic prediction
            
            # get the two models for this site + common_name
            model_all = self.linear_models_allreadings[i]
            model_last = self.linear_models_lastreadings[i]
            
            if not model_all: #In case of minimal number of points
                if not last_valid_idx:
                    row_prediction_array = last_valid_count #no data, prediction of 1
                else:
                    row_prediction_array = last_valid_count * CONSTANT_TREND_FOR_NO_DATA #very few observations (1-2), use the last valid 1 (could use average as well)
            else:
                # make the linear predictions using the model
                row_predictions_all = model_all.predict(
                    self.submission_format.columns.values.reshape(-1, 1)
                )

                row_predictions_last = model_last.predict(
                    self.submission_format.columns.values.reshape(-1, 1)
                )
                
                # add all the model factors, baseline + 2 trends
                row_prediction_array = []
                for j, year in enumerate(self.submission_format.columns):
                    if year == 2014 or year == 2015:
                        row_prediction = self._modelForData20142015(model_last, model_all, last_valid_count, j + 1)
                    if year == 2016 or year == 2017:
                        row_prediction = self._modelForData20162017(model_last, model_all, last_valid_count, j + 1)
                    row_prediction_array.append(row_prediction[0]) #row_prediction[0] to preserve structure
               
            # keep our predictions, rounded to nearest whole number
            non_negative_pred = np.amax(np.stack([minimal_pred, row_prediction_array], axis = 0), axis = 0)
            preds.append(non_negative_pred)

        # Create a dataframe that we can write out to a CSV
        self.prediction_df = pd.DataFrame(preds,
                                     index=self.submission_format.index,
                                     columns=self.submission_format.columns)

        self.prediction_df.head()
        return self.prediction_df
    
    # The model for 2014 - 2015, has some small factor of increase. 
    # Pay attention that in both models it is assumed that last prediction is in 2013
    # meaning that the slope is multiplied by the years passed since 2013, even if last mesurements happened before.
    def _modelForData20142015(self, model_last, model_all, last_valid_count, years_from_2013):
        prediction_addition_last = years_from_2013 * (model_last.coef_) * np.power(LAST_TREND_WEIGHT_YEARS_1_2, years_from_2013) 
        prediction_addition_all = years_from_2013 * (model_all.coef_) * GENERAL_TREND_WEIGHT
        prediction_1 = last_valid_count + prediction_addition_last + prediction_addition_all
        prediction_final = LINEAR_MODEL_FACTOR * (prediction_1 + last_valid_count * np.power(CONSTANT_TREND_FOR_MODELS, TIME_FOR_INCREASE_FACTOR - years_from_2013 + 1)); #small boost to first year
        return prediction_final
    
    # The model for 2016 - 2017. 
    def _modelForData20162017(self, model_last, model_all, last_valid_count, years_from_2013):
        prediction_addition_last = (years_from_2013) * (model_last.coef_) * np.power(LAST_TREND_WEIGHT_YEARS_3_4, years_from_2013)
        prediction_addition_all = (years_from_2013) * (model_all.coef_) * GENERAL_TREND_WEIGHT
        prediction_final = last_valid_count + LINEAR_MODEL_FACTOR * (prediction_addition_last + prediction_addition_all)
        return prediction_final
    
    def savePrediction(self):
        prediction_path = os.path.join(self.path_to_predictions, self.prediction_file)
        self.prediction_df.to_csv(prediction_path)