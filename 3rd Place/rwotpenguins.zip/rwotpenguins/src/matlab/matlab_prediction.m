%% This script predicts the value, as the last observation
load_data
T_output = readtable('Random_Walk_of_the_Penguins_-_Submission_Format.csv', 'readVariableName', false);
assert(all(strcmp(T_count{2:end, 1}, T_output{2:end, 1})))
%%
for ii = 1:size(nestCounts, 1)
    V = nestCounts(ii, :);
    vValid = V(~isnan(V));
    if length(vValid) < 1
        vValid(1) = 0;
    end
    if numberOfNonZeroVals(ii) <= 2
        curOutput = repmat(nanmax(lastValidCounts(ii) * (39/36), 0), 1, 4);
    else
        for jj = 1:2
            curOutput(jj) = lastValidCounts(ii) + jj*(lastTrend(ii) * .7.^jj) + jj * generalTrend(ii) * .1;
            curOutput(jj) = (curOutput(jj) + lastValidCounts(ii) * ((19/18) .^(3-jj)))/2 ;
        end
        for jj = 3:4
            curOutput(jj) = lastValidCounts(ii) + (jj)*(lastTrend(ii) * .6.^jj) + jj * generalTrend(ii) * .1;
            curOutput(jj) = (curOutput(jj) + lastValidCounts(ii))/2;
        end
    end
    T_output{ii+1, 3:6} = curOutput*1.0000001;
end
%%
%T_output = {'site_id', 'common_name',
writetable(T_output, ['./Submissions/submission_linear_' date '.csv'], 'WriteVariableNames', false);