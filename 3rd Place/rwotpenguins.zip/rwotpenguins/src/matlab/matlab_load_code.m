clear; clc; close all;
%% Load data
T = readtable('Random_Walk_of_the_Penguins_-_Nest_count_timeseries.csv', 'readVariableName', false);
T_errors = readtable('Random_Walk_of_the_Penguins_-_Nest_error_timeseries.csv', 'readVariableName', false);

%% Process data
years = table2array(T(1, 3:end));
nestCounts = table2array(T(2:end, 3:end));
errs = table2array(T_errors(2:end, 3:end));

%% Now we shall format the data
for ii = 1:size(nestCounts, 1)
    V = nestCounts(ii, :);
    vValid = V(~isnan(V));
    numberOfNonZeroVals(ii) = sum(~isnan(V));
    
    currentErr = errs(ii, :);
    eValid = currentErr(~isnan(currentErr));
    if ~isempty(vValid)
        correlationCoeffs(ii) = corr(years(~isnan(V))', vValid');
        lastValidCounts(ii) = vValid(end);
    else
        correlationCoeffs(ii) = nan;
        lastValidCounts(ii) = nan;
    end
    idxs = find(~isnan(V));
    
    if numberOfNonZeroVals(ii) >= 6
        LM = fitlm(years(idxs(end-5:end))', vValid(end-5:end)');
        lastTrend(ii) = LM.Coefficients.Estimate(2);
        LM = fitlm(years(idxs)', vValid');
        generalTrend(ii) = LM.Coefficients.Estimate(2);
    elseif numberOfNonZeroVals(ii) > 1
        LM = fitlm(years(idxs)', vValid');
        lastTrend(ii) = LM.Coefficients.Estimate(2);
        generalTrend(ii) = LM.Coefficients.Estimate(2);
    else
        lastTrend(ii) = nan;
        generalTrend(ii) = nan;
    end
    if ~isempty(eValid)
        e(ii) = eValid(end);
    else
        e(ii) = nan;
    end
end

%%
figure,
correlationCoeffs = randperm(size(nestCounts, 1), 36);
for ii = 1:36
    subplot(6,6, ii);
    scatter(years, nestCounts(correlationCoeffs(ii),:), 'filled');
    title(sprintf('row #%d, err:%.2f', correlationCoeffs(ii), e(correlationCoeffs(ii))));
end
%%