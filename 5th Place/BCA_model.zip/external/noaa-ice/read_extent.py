import os
import pandas as pd
import numpy as np
pd.options.display.max_rows = 10
import matplotlib.pyplot as plt
plt.style.use('ggplot')

csvs    = [x for x in os.listdir('.') if x.endswith('.csv')]

dfs = []
for csv in csvs:
    df          = pd.read_csv(csv, na_values=[-9999.])
    cols        = df.columns
    newcols     = [x.replace(' ', '') for x in cols]
    df.columns  = newcols
    dfs.append(df)
    
DF  = pd.concat(dfs)
DF.index = DF.apply(lambda x:pd.datetime.strptime("{} {}".format(x['year'],x['mo']), "%Y %m"),axis=1)
DF = DF.sort_index()
DF.to_pickle('S_extent.p')