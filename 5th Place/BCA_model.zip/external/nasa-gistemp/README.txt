README NASA-GISTEMP

source: https://data.giss.nasa.gov/gistemp/

-----------------------------------------------------------------------------------------------
Compressed NetCDF Files (regular 2°×2° grid)
Land-Ocean Temperature Index, ERSSTv4, 1200km smoothing (23 MB)
Surface air temperature (no ocean data), 250km smoothing (9 MB)

-----------------------------------------------------------------------------------------------
Tables of Global and Hemispheric Monthly Means and Zonal Annual Means
THe following are plain-text files in tabular format of temperature anomalies, i.e. deviations from the corresponding 1951-1980 means.

Combined Land-Surface Air and Sea-Surface Water Temperature Anomalies (Land-Ocean Temperature Index, LOTI)
Global-mean monthly, seasonal, and annual means, 1880-present, updated through most recent month: TXT, CSV
Northern Hemisphere-mean monthly, seasonal, and annual means, 1880-present, updated through most recent month: TXT, CSV
Southern Hemisphere-mean monthly, seasonal, and annual means, 1880-present, updated through most recent month: TXT, CSV
Zonal annual means, 1880-present, updated through most recent complete year: TXT, CSV
Note: LOTI provides a more realistic representation of the global mean trends than dTs below; it slightly underestimates warming or cooling trends, since the much larger heat capacity of water compared to air causes a slower and diminished reaction to changes; dTs on the other hand overestimates trends, since it disregards most of the dampening effects of the oceans that cover about two thirds of the Earth's surface.
