FOLDER STRUCTURE

|---data                <-  where original data from DrivenData are
|---external            <-  other sources for covariates
|---notebooks           <-  used for exploration of data and possible models
|---submissions         <-  where all submitted files are
|---
|---README.txt          <-  this file
|---requirements.txt    <-  as obtained with conda.
|                           can be used to install with conda with the following command:
|                           conda install --yes --file requirements.txt
|---linear_sens.ipynb   <-  used to compute the forecast of penguin popultaion
                            only input are the rates of change, stored in file beta.csv
|---beta.csv            <-  rates of change of population per penguin
                            referred to the last measured year

In order to reproduce the submission, first install all the requirements for python 3
Then run the notebook linear_sens, without changing the values in beta.csv
The result will be stored under folder submissions