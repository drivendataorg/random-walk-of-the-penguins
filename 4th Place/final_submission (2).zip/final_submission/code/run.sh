#!/bin/bash

jupyter nbconvert --to notebook --ExecutePreprocessor.timeout=2000 --execute 0_subm_5.2274/test_model.ipynb
jupyter nbconvert --to notebook --ExecutePreprocessor.timeout=2000 --execute 1_subm_5.2106/test_model.ipynb
jupyter nbconvert --to notebook --ExecutePreprocessor.timeout=2000 --execute 2_subm_5.2136/test_model.ipynb
jupyter nbconvert --to notebook --ExecutePreprocessor.timeout=2000 --execute 3_subm_5.9463/test_model.ipynb
jupyter nbconvert --to notebook --ExecutePreprocessor.timeout=2000 --execute 4_subm_5.2138/test_model.ipynb
jupyter nbconvert --to notebook --ExecutePreprocessor.timeout=2000 --execute 5_subm_5.2136/test_model.ipynb
jupyter nbconvert --to notebook --ExecutePreprocessor.timeout=2000 --execute 6_subm_5.2136/test_model.ipynb
jupyter nbconvert --to notebook --ExecutePreprocessor.timeout=2000 --execute 7_subm_6.2682/test_model.ipynb

python ensemble.py