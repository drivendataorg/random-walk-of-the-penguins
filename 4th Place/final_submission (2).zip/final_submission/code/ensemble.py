import numpy as np
import pandas as pd
import glob

files = glob.glob('*/*.csv')

files = ['0_subm_5.2274/predictions.csv',
		 '1_subm_5.2106/predictions.csv',
		 '2_subm_5.2136/predictions.csv',
		 '4_subm_5.2138/predictions.csv',
		 '5_subm_5.2136/predictions.csv',
		 '6_subm_5.2136/predictions.csv',
		]
		
buf = []
for file in files:
	print(file)
	df = pd.read_csv(file)
	data = np.array(df[['2014', '2015', '2016', '2017']])

	buf.append(data)
	site_id = df['site_id'].values
	common_name = df['common_name'].values

mean_data = np.round(np.mean(np.array(buf), axis=0))
print(mean_data.shape)

subm = pd.DataFrame()

subm['site_id'] = site_id
subm['common_name'] = common_name
subm['2014'] = mean_data[:, 0]
subm['2015'] = mean_data[:, 1]
subm['2016'] = mean_data[:, 2]
subm['2017'] = mean_data[:, 3]

print(subm.head(20))

subm.to_csv('ensemble_submission.csv', index=False)
